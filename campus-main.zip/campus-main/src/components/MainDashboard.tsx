import React, { useState } from 'react';
import {
  Drawer,
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CssBaseline,
  Divider,
  Box,
  Tooltip,
  Container,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Home,
  Feed,
  Book,
  Group,
  Person,
  ExitToApp,
} from '@mui/icons-material';
import Feeds from './Feeds';
import StudyGroupsPage from './StudyGroups';
import Profile from './MyProfile';
import Dashboard from './Dashboard';
import { Grid, Link, useAuthenticator } from '@aws-amplify/ui-react';
import ResourcePage from './Resources';
import facebook from '../assets/facebook.svg';
import twitter from '../assets/twitter.svg';
import linkedin from '../assets/linkedin.svg';
import instagram from '../assets/instagram.svg';
import connection from '../assets/connection.png';


function MainDashboard(props) {
  const [component, setComponent] = useState(1);
  const [header, setHeader] = useState('Campus Connect');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeItem, setActiveItem] = useState(1); // Track the active menu item

  const switchComponent = (page) => {
    setComponent(page);
    setActiveItem(page); // Update the active item
    setDrawerOpen(false);
  };

  const renderComponent = () => {
    switch (component) {
      case 1:
        return <Dashboard handler={setHeader} />;
      case 2:
        return <Feeds setHeader={setHeader} />;
      case 3:
        return <ResourcePage setHeader={setHeader} />;
      case 4:
        return <StudyGroupsPage handler={setHeader} />;
      case 5:
        return <Profile handler={setHeader} />;
      default:
        return <div>{component}</div>;
    }
  };

  const { signOut } = useAuthenticator();

  const trySignOut = () => {
    signOut();
  };

  const toggleDrawer = (open) => {
    setDrawerOpen(open);
  };

  const handleNavigation = [
    { text: 'Dashboard', icon: <Home />, component: 1 },
    { text: 'Forums', icon: <Feed />, component: 2 },
    { text: 'Resources', icon: <Book />, component: 3 },
    { text: 'Study Groups', icon: <Group />, component: 4 },
    { text: 'My Profile', icon: <Person />, component: 5 },
    { text: 'Sign Out', icon: <ExitToApp />, action: trySignOut },
  ];

  return (
    <div className="wrapper" style={{ display: 'flex', backgroundColor: '#f5f5f5' ,flexDirection: 'column' }}>
      <CssBaseline />
      <AppBar sx={{ zIndex: 1200, bgcolor: '#1a73e8' }}>
        <Toolbar>
          <IconButton
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={() => toggleDrawer(true)}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" noWrap sx={{ flexGrow: 1, fontWeight: 'bold' }}>
            {header}
          </Typography>
        </Toolbar>
      </AppBar>

      <Drawer
        open={drawerOpen}
        onClose={() => toggleDrawer(false)}
        sx={{
          '& .MuiDrawer-paper': {
            width: 250, // Adjusted width for a richer feel
            bgcolor: 'linear-gradient(0deg, #1a73e8, #66bbff)', // Gradient background
            color: '#000', // White text for contrast
            paddingTop: '0px',
            boxShadow: '4px 4px 10px rgba(0, 0, 0, 0.2)', // Shadow for depth
            borderRadius: '0px 0 0 0px', // Rounded corners for sidebar
            transition: 'all 0.3s ease-in-out', // Smooth transition effect
          },
        }}
      >
        <Box sx={{ padding: '0 0px' }}>
          <Typography variant="h6" sx={{ padding: '8px 0', color: '#000' }}>
           <span style={{display:'flex',alignItems:'center',justifyContent:'center'}}> <img src={connection} alt="connect" width={'30px'} height={'30px'}/> &nbsp; Campus Connect</span>
          </Typography>
          <Divider sx={{ marginBottom: '10px', bgcolor: '#eee' }} />
          <List>
            {handleNavigation.map((item, index) => (
              <Tooltip title={item.text} placement="right" key={index}>
                <ListItem
                  button
                  onClick={item.action ? item.action : () => switchComponent(item.component)}
                  sx={{
                    '&:hover': {
                      bgcolor: '#f4f4f4', // Light hover effect
                    },
                    padding: '8px 16px',
                    borderRadius: '0px',
                    margin: '0px 0 0',
                    backgroundColor: activeItem === item.component ? '#f4f4f4' : 'transparent', // Highlight active item
                  }}
                >
                  <ListItemIcon style={{minWidth:'40px'}} sx={{ color: 'inherit' }}>{item.icon}</ListItemIcon>
                  <ListItemText
                    primary={item.text}
                    sx={{
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: 'inherit',
                      cursor:'pointer'
                    }}
                  />
                </ListItem>
              </Tooltip>
            ))}
          </List>
        </Box>
      </Drawer>

      <main style={{ flex: 1, marginTop: '64px', padding: '16px' }}>
        {renderComponent()}
      </main>
      <Footer/>

    </div>
  );
}

export default MainDashboard;


const Footer = () => {
  return (
    <footer style={{ backgroundColor: '#1a1a1a', color: '#ffffff', padding: '20px', marginTop: '40px' }}>
      <div style={{ width:'100%', margin: '0 auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', flexDirection:'row' }}>
        <div className='aboutus-block' style={{ flex: '1 0 25%', maxWidth: '25%', marginBottom: '20px' }}>
          <h3>About Us</h3>
          <p style={{ fontSize: '14px', color: '#cccccc' }}>
            We are committed to delivering the best online resources for our users. Contact us for more information.
          </p>
        </div>
        
        <div className="follow-block" style={{ flex: '1 0 25%', maxWidth: '25%', marginBottom: '20px',textAlign:'center' }}>
          <h3>Follow Us</h3>
          <p style={{ fontSize: '14px' }}>
            <a href="#" style={{ color: '#ffffff', textDecoration: 'none', marginRight: '10px' }}>
              <img src={facebook} width={'30px'} height={'30px'} alt='facebook' />
            </a>
            <a href="#" style={{ color: '#ffffff', textDecoration: 'none', marginRight: '10px' }}>
              <img src={twitter} width={'30px'} height={'30px'} alt='Twitter' />
            </a>
            <a href="#" style={{ color: '#ffffff', textDecoration: 'none', marginRight: '10px' }}>
              <img src={linkedin} width={'30px'} height={'30px'} alt='Linkedin' />
            </a>
            <a href="#" style={{ color: '#ffffff', textDecoration: 'none' }}>
              <img src={instagram} width={'30px'} height={'30px'} alt='Instagram' />
            </a>
          </p>
        </div>
      </div>
      <div style={{ textAlign: 'center', color: '#fff', fontSize: '14px', marginTop: '20px' }}>
        © {new Date().getFullYear()} Indiana Campus Connect. All rights reserved.
      </div>
    </footer>
  );
};

